import React, { useState } from 'react';
import axios from 'axios';
import CardAtleta from './components/CardAtleta';
import PainelFavoritos from './components/PainelFavoritos';

function App() {
  const [nome, setNome] = useState('');
  const [resultados, setResultados] = useState([]);
  const [favoritos, setFavoritos] = useState([]);
  const [erro, setErro] = useState('');

  const buscarAtleta = async () => {
    console.log("Chave usada:", process.env.REACT_APP_RAPIDAPI_KEY);

    if (!nome) return;

    const options = {
      method: 'GET',
      url: 'https://api-football-v1.p.rapidapi.com/v3/players',
      params: { search: nome, season: '2023' },
      headers: {
        'X-RapidAPI-Key': process.env.REACT_APP_RAPIDAPI_KEY,
        'X-RapidAPI-Host': 'api-football-v1.p.rapidapi.com'
      }
    };

    try {
      const response = await axios.request(options);
      console.log('Dados recebidos:', response.data);
      setResultados(response.data.response);
      setErro('');
    } catch (error) {
      console.error('Erro na busca:', error);
      setErro('Erro ao buscar jogador. Verifique o nome ou a chave da API.');
    }
  };

  const adicionarFavorito = (atleta) => {
    const jaExiste = favoritos.some(fav => fav.player.id === atleta.player.id);
    if (!jaExiste) {
      setFavoritos((prev) => [...prev, atleta]);
    }
  };

  return (
    <div style={{ padding: 20, fontFamily: 'Arial, sans-serif' }}>
      <h1>Busca de Jogadores de Futebol</h1>

      <input
        type="text"
        placeholder="Digite o nome do jogador (ex: Messi)"
        value={nome}
        onChange={(e) => setNome(e.target.value)}
        style={{ padding: 8, fontSize: 16 }}
      />
      <button onClick={buscarAtleta} style={{ marginLeft: 10, padding: 8, fontSize: 16 }}>
        Buscar
      </button>

      {erro && <p style={{ color: 'red' }}>{erro}</p>}

      <div style={{ display: 'flex', flexWrap: 'wrap', marginTop: 20 }}>
        {resultados.map((atleta, idx) => (
          <CardAtleta
            key={idx}
            atleta={atleta}
            adicionarFavorito={adicionarFavorito}
          />
        ))}
      </div>

      <PainelFavoritos favoritos={favoritos} />
    </div>
  );
}

export default App;
